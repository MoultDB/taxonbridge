library(testthat)
library(moultdbtools)

test_check("moultdbtools")
