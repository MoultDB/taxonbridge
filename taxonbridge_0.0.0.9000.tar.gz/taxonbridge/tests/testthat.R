library(testthat)
library(taxonbridge)

test_check("taxonbridge")
